package com.example.demo.service;

import com.example.demo.model.Student;

public interface StudentService {

    boolean entityValidation(Student student);


}
